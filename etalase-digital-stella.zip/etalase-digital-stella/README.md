# Etalase Digital Stella (PHP Native + CSS)

Wadah karya digital siswa dengan login multi-role (Super Admin, Admin, Siswa).

## Cara Menjalankan (XAMPP / Laragon)

1. Copy folder `etalase-digital-stella` ke `htdocs` (XAMPP) atau `www` (Laragon).
2. Nyalakan **Apache** dan **MySQL**.
3. Buka **phpMyAdmin** → tab **Import** → pilih file `database.sql` → Go.
4. Cek `config/database.php`:
   - `BASE_URL` = nama folder project (default `/etalase-digital-stella`)
   - `DB_USER` / `DB_PASS` sesuai MySQL kamu (default XAMPP: `root` tanpa password)
5. Buka `http://localhost/etalase-digital-stella`
6. Pastikan folder `uploads/` bisa ditulis (writable).

## Akun Uji (password: `password123`)

| Role        | Email                     |
|-------------|---------------------------|
| Super Admin | superadmin@stella.sch.id  |
| Admin       | admin@stella.sch.id       |
| Siswa       | siswa@stella.sch.id       |

## Hak Akses

| Fitur                                   | Super Admin | Admin              | Siswa |
|-----------------------------------------|:-----------:|:------------------:|:-----:|
| Kelola User/Admin                       | ✅          | ✅ (data siswa saja) | ❌   |
| Kelola semua karya (CRUD)               | ✅          | ✅                 | ❌    |
| Lihat semua karya                       | ✅          | ✅                 | ✅    |
| Tambah karya sendiri                    | ✅          | ✅                 | ✅    |
| Edit / hapus karya sendiri              | ✅          | ✅                 | ✅    |

## Struktur Folder

```
etalase-digital-stella/
├── config/database.php      # Koneksi DB + BASE_URL
├── includes/
│   ├── auth.php             # Middleware login & role, CSRF, upload gambar
│   ├── header.php / footer.php
│   └── project_card.php     # Komponen kartu karya
├── admin/
│   ├── index.php            # Panel admin: kelola semua karya
│   ├── users.php            # Kelola user / data siswa
│   ├── user_form.php        # Tambah / edit user
│   └── user_delete.php
├── assets/css/style.css
├── uploads/                 # Gambar karya (dilindungi .htaccess)
├── index.php                # Landing page
├── login.php / register.php / logout.php
├── projects.php             # Etalase semua karya
├── my_projects.php          # Karya milik sendiri
├── project_detail.php
├── project_form.php         # Tambah & edit karya
├── project_delete.php
└── database.sql
```
